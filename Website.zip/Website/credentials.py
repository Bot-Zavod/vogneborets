dbname = 'Twinkly'
user = 'twinklyadmin'
password = 'tfEJQjqS8wYvH23xEcGH'
host = 'twinkly-dev.cc4xdtflaafw.us-west-2.rds.amazonaws.com'
port = 5433